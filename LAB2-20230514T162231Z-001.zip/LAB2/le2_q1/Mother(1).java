class Mother
{
    int x;
    void show()
    {
    System.out.println("this is mother class function");
    }
}