class Child extends Mother
{
    
}