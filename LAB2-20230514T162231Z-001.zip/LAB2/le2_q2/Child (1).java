class Child extends Mother
{
    public void show()
    {
        System.out.println("Hello JUET");
    }
}